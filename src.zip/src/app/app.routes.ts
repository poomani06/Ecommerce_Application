import { Routes } from '@angular/router';
import { Home } from './features/home/home';
import { Categories } from './features/categories/categories';
import { Products } from './features/products/products';
import { ProductDetails } from './features/product-details/product-details';
import { Login } from './features/auth/login/login';
import { Register } from './features/auth/register/register';
import { Products as AdminProducts } from './features/admin/products/products';


export const routes: Routes = [
  {
    path: '',
    component: Home
  },
  {
    path: 'categories',
    component: Categories
  },
  {
  path: 'products',
  component: Products
  },
  { path: 'products/:id', component: ProductDetails },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  {
  path: 'admin/products',
  component: AdminProducts
},
  {
    path: '**',
    redirectTo: ''
  }
];