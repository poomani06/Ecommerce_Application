import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../../core/services/product';
import { Product } from '../../../models/product.model';

@Component({
  selector: 'app-admin-products',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './products.html',
  styleUrl: './products.css'
})
export class Products implements OnInit {

  products: Product[] = [];
  errorMessage = '';
  successMessage = '';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getProducts('', undefined, 1, 100).subscribe({
      next: (response: { products: Product[] }) => {
        this.products = response.products;
      },
      error: () => {
        this.errorMessage = 'Failed to load products.';
      }
    });
  }

  deleteProduct(id: number): void {
    if (!confirm('Are you sure you want to deactivate this product?')) {
      return;
    }

    this.productService.deleteProduct(id).subscribe({
      next: (response: { message: string }) => {
        this.successMessage = response.message;
        this.loadProducts();
      },
      error: () => {
        this.errorMessage = 'Failed to deactivate product.';
      }
    });
  }
}